import os
import joblib
import pandas as pd
import numpy as np
import streamlit as st
import matplotlib.pyplot as plt

st.set_page_config(
    page_title="Air Quality Prediction",
    page_icon="🌍",
    layout="wide"
)

st.markdown(
    '''
    <style>
    .main-title {
        font-size: 42px;
        font-weight: 800;
        margin-bottom: 0;
    }
    .subtitle {
        color: #666;
        font-size: 18px;
        margin-bottom: 25px;
    }
    .result-box {
        padding: 20px;
        border-radius: 14px;
        background: #f5f7fa;
        margin-top: 10px;
    }
    </style>
    ''',
    unsafe_allow_html=True
)

st.markdown('<div class="main-title">🌍 Air Quality Prediction System</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="subtitle">AI-powered prediction of Air Quality Index using environmental and weather parameters.</div>',
    unsafe_allow_html=True
)

if not os.path.exists("air_quality_model.pkl"):
    st.warning("ML model is not available yet. Run `python train_model.py` in the VS Code terminal.")
    st.stop()

model = joblib.load("air_quality_model.pkl")

def category(aqi):
    if aqi <= 50:
        return "Good", "Air quality is satisfactory. Outdoor activities are generally safe."
    if aqi <= 100:
        return "Moderate", "Air quality is acceptable. Sensitive people should monitor conditions."
    if aqi <= 150:
        return "Poor", "Sensitive groups should reduce prolonged outdoor activity."
    if aqi <= 200:
        return "Very Poor", "Health alert. Reduce prolonged outdoor activity."
    return "Severe", "Health emergency. Avoid outdoor activity where possible."

st.sidebar.header("🌫️ Input Parameters")
st.sidebar.caption("Enter current environmental conditions.")

pm25 = st.sidebar.slider("PM2.5 (µg/m³)", 0.0, 300.0, 50.0)
pm10 = st.sidebar.slider("PM10 (µg/m³)", 0.0, 400.0, 80.0)
no2 = st.sidebar.slider("NO₂ (ppb)", 0.0, 200.0, 40.0)
co = st.sidebar.slider("CO (ppm)", 0.0, 10.0, 1.0)
temperature = st.sidebar.slider("Temperature (°C)", 10.0, 50.0, 30.0)
humidity = st.sidebar.slider("Humidity (%)", 0.0, 100.0, 60.0)
wind = st.sidebar.slider("Wind Speed (km/h)", 0.0, 20.0, 5.0)

input_data = pd.DataFrame([{
    "PM2.5": pm25,
    "PM10": pm10,
    "NO2": no2,
    "CO": co,
    "Temperature": temperature,
    "Humidity": humidity,
    "Wind Speed": wind
}])

if st.button("🔍 Predict Air Quality", type="primary", use_container_width=True):
    aqi = float(model.predict(input_data)[0])
    aqi = float(np.clip(aqi, 0, 500))

    level, message = category(aqi)

    st.divider()
    st.subheader("📊 Prediction Result")

    c1, c2, c3 = st.columns(3)
    c1.metric("Predicted AQI", f"{aqi:.1f}")
    c2.metric("Air Quality", level)
    c3.metric("Temperature", f"{temperature:.1f} °C")

    st.info(message)

    st.subheader("❤️ Health Recommendation")
    if level == "Good":
        st.success("Normal outdoor activities can be continued.")
    elif level == "Moderate":
        st.info("Most people can continue normal activities. Sensitive people should monitor symptoms.")
    elif level == "Poor":
        st.warning("Children, elderly people and sensitive individuals should reduce prolonged outdoor activity.")
    elif level == "Very Poor":
        st.warning("Avoid prolonged outdoor activity and consider using a suitable mask outdoors.")
    else:
        st.error("Avoid outdoor activity where possible and follow local air-quality advisories.")

    st.subheader("🌫️ Environmental Conditions")
    display = pd.DataFrame({
        "Parameter": ["PM2.5", "PM10", "NO₂", "CO", "Temperature", "Humidity", "Wind Speed"],
        "Value": [
            f"{pm25:.1f} µg/m³",
            f"{pm10:.1f} µg/m³",
            f"{no2:.1f} ppb",
            f"{co:.2f} ppm",
            f"{temperature:.1f} °C",
            f"{humidity:.1f} %",
            f"{wind:.1f} km/h"
        ]
    })
    st.dataframe(display, use_container_width=True, hide_index=True)

    st.subheader("📈 Environmental Parameter Graph")
    graph = pd.DataFrame({
        "Parameter": ["PM2.5", "PM10", "NO2", "CO", "Temperature", "Humidity", "Wind Speed"],
        "Value": [pm25, pm10, no2, co, temperature, humidity, wind]
    })

    fig, ax = plt.subplots(figsize=(10, 4.5))
    ax.bar(graph["Parameter"], graph["Value"])
    ax.set_xlabel("Parameter")
    ax.set_ylabel("Value")
    ax.set_title("Current Environmental Conditions")
    plt.xticks(rotation=25)
    plt.tight_layout()
    st.pyplot(fig)

st.divider()

if os.path.exists("air_quality_data.csv"):
    st.subheader("📁 Training Dataset")
    data = pd.read_csv("air_quality_data.csv")
    st.caption(f"{len(data):,} training records")
    st.dataframe(data.head(20), use_container_width=True, hide_index=True)

    st.subheader("📊 AQI Distribution")
    fig2, ax2 = plt.subplots(figsize=(10, 4))
    ax2.hist(data["AQI"], bins=30)
    ax2.set_xlabel("AQI")
    ax2.set_ylabel("Frequency")
    ax2.set_title("Training Dataset AQI Distribution")
    plt.tight_layout()
    st.pyplot(fig2)

st.divider()
st.caption("Educational ML project • Python • Streamlit • Pandas • Scikit-learn • Random Forest")
