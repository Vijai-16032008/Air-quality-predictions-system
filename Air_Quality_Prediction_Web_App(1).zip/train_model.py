import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score
import joblib

np.random.seed(42)

N = 2500

pm25 = np.random.uniform(5, 300, N)
pm10 = np.random.uniform(10, 400, N)
no2 = np.random.uniform(5, 200, N)
co = np.random.uniform(0.1, 10, N)
temperature = np.random.uniform(15, 45, N)
humidity = np.random.uniform(20, 95, N)
wind_speed = np.random.uniform(0.5, 20, N)

aqi = (
    pm25 * 0.55
    + pm10 * 0.25
    + no2 * 0.15
    + co * 3
    + humidity * 0.05
    - wind_speed * 0.5
    + np.random.normal(0, 5, N)
)

aqi = np.clip(aqi, 0, 500)

data = pd.DataFrame({
    "PM2.5": pm25,
    "PM10": pm10,
    "NO2": no2,
    "CO": co,
    "Temperature": temperature,
    "Humidity": humidity,
    "Wind Speed": wind_speed,
    "AQI": aqi
})

data.to_csv("air_quality_data.csv", index=False)

features = [
    "PM2.5", "PM10", "NO2", "CO",
    "Temperature", "Humidity", "Wind Speed"
]

X = data[features]
y = data["AQI"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = RandomForestRegressor(
    n_estimators=200,
    random_state=42,
    n_jobs=-1
)

model.fit(X_train, y_train)

pred = model.predict(X_test)

print("Air Quality Prediction Model")
print("=" * 40)
print(f"MAE: {mean_absolute_error(y_test, pred):.2f}")
print(f"R2 Score: {r2_score(y_test, pred):.2f}")

joblib.dump(model, "air_quality_model.pkl")
print("Model saved: air_quality_model.pkl")
print("Dataset saved: air_quality_data.csv")
