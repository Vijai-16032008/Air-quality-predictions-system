@echo off
echo Starting Air Quality Prediction App...
if not exist venv (
    python -m venv venv
)
call venv\Scripts\activate
pip install -r requirements.txt
if not exist air_quality_model.pkl (
    python train_model.py
)
streamlit run app.py
pause
