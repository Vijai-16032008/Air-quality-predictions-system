# Air Quality Prediction Web Application

## Run in VS Code

1. Open this folder in VS Code.
2. Open Terminal.
3. Create a virtual environment:

```bash
python -m venv venv
```

4. Activate it on Windows:

```bash
venv\Scripts\activate
```

5. Install packages:

```bash
pip install -r requirements.txt
```

6. Train the model:

```bash
python train_model.py
```

7. Start the web application:

```bash
streamlit run app.py
```

The browser will open the Air Quality Prediction dashboard.

## Features

- AQI prediction using machine learning
- PM2.5, PM10, NO2 and CO inputs
- Temperature, humidity and wind speed inputs
- AQI category and health recommendation
- Environmental parameter chart
- Training dataset preview
- AQI distribution chart
- Responsive Streamlit dashboard

This project uses a generated educational dataset so it runs immediately without downloading external data.
